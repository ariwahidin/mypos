<?php
var_dump($stock_in);
