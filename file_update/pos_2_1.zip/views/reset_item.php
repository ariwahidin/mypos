<form action="" method="post">
    <label for="">Exp Date</label>
    <input type="date" name="exp_date">
    <label for="">Qty</label>
    <input type="number" name="qty">
    <button type="submit">Save</button>
</form>