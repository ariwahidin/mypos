<section class="content-header">
    <h1>Migrasi
        <small>Update table</small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <a href="<?= base_url('migrasi/updateTable') ?>">Update Table</a>
        </div>
    </div>
</section>