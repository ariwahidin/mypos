<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Upload_m extends CI_Model {

}